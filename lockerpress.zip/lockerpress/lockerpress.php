<?php

/*
Plugin Name: LockerPress
Plugin URI: http://lockerpress.com
Description: WordPress Security Plugin by LockerPress. Create Custom Login URL (hides default wp-admin & wp-login URL's), Change Admin User, Custom Hack/Ban Settings, Change Database Prefix & much more to give you peace of mind.
Version: 1.0
Author: LockerPress
Author URI: http://lockerpress.com
License:
*/

require_once dirname(__FILE__) . '/core.php';